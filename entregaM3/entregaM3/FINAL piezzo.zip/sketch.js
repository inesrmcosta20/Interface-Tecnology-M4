let video;
let bodyPose;
let poses = [];
let time = 0;
let port;
let connectBtn;
let distanciaSensor = 400; 

let threshold = 1000; 


let mostrarCamera = true;   
let estadoBotaoAntigo = 1;  

function preload() {
  bodyPose = ml5.bodyPose("MoveNet");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  // Modo HSB
  colorMode(HSB, 360, 100, 100, 1); 

  port = createSerial();
  connectBtn = createButton("Ligar Arduino");
  connectBtn.position(10, 10); 
  connectBtn.mousePressed(conectarArduino);

  video = createCapture(VIDEO);
  video.size(640, 480); 
  video.hide();
  bodyPose.detectStart(video, gotPoses);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

// Conexão segura para evitar o erro de "locked stream"
async function conectarArduino() {
  try {
    if (!port.opened()) {
      await port.open(9600);
    } else {
      await port.close();
    }
  } catch (err) {
    console.log("Erro ao abrir/fechar a porta: " + err);
  }
}

function gotPoses(results) {
  poses = results;
}

function draw() {
  
  background(0, 0, 0); 

  // Leitura segura dos dados da Porta Serial
  if (port.opened() && port.available() > 0) {
    let inString = port.readUntil("\n");
    if (inString) {
      let dados = split(trim(inString), ','); 
      
      if (dados.length >= 2) {
        distanciaSensor = float(dados[0]);
        let estadoBotaoFisico = int(dados[1]);
        
        if (estadoBotaoFisico === 0 && estadoBotaoAntigo === 1) {
          mostrarCamera = !mostrarCamera; 
        }
        estadoBotaoAntigo = estadoBotaoFisico; 
      }
    }
  }

//botão
  connectBtn.html(port.opened() ? "Desligar Arduino" : "Ligar Arduino");

  
  if (mostrarCamera) {
    push();
    translate(width, 0); 
    scale(-1, 1); 
    drawingContext.filter = 'grayscale(100%)'; 
    image(video, 0, 0, width, height); 
    drawingContext.filter = 'none'; 
    pop();
  }


  if (poses && poses.length > 0 && distanciaSensor < threshold) {
    let ritmoMaisRapido = 1000; 

    for (let i = 0; i < poses.length; i++) {
      let pose = poses[i];
      let matiz = 240; // Azul 
      
      if (poses.length > 1) {
        let menorDist = 1000;
        for (let j = 0; j < poses.length; j++) {
          if (i !== j) {
            let d = dist(pose.keypoints[0].x, pose.keypoints[0].y, 
                         poses[j].keypoints[0].x, poses[j].keypoints[0].y);
            if (d < menorDist) menorDist = d;
          }
        }
        
        // vermelho 
        matiz = map(menorDist, 100, 400, 0, 240, true);
        
        //formas
        ritmoMaisRapido = map(matiz, 0, 240, 200, 1000); 
      }

      
      drawBodyFormFullscreen(pose, color(matiz, 80, 90, 0.6));
    }
    
    //ritmo
    if (port.opened()) {
      port.write(int(ritmoMaisRapido) + ",1\n");
    }
    time += 0.02;

  } else {
 
    if (port.opened()) {
      port.write("1000,0\n");
    }

    if (distanciaSensor >= threshold) {
      push();
      fill(0, 80, 80); 
      textAlign(CENTER);
      textSize(18);
      text("Fora de alcance (" + int(distanciaSensor) + "cm)", width / 2, height - 30);
      pop();
    }
  }
}


function drawBodyFormFullscreen(pose, cor) {
  let sL_x = width - map(pose.keypoints[5].x, 0, 640, 0, width);
  let sL_y = map(pose.keypoints[5].y, 0, 480, 0, height);
  let sR_x = width - map(pose.keypoints[6].x, 0, 640, 0, width);
  let sR_y = map(pose.keypoints[6].y, 0, 480, 0, height);

  let prox = pose.keypoints[5].confidence > 0.1 && pose.keypoints[6].confidence > 0.3
      ? dist(sL_x, sL_y, sR_x, sR_y)
      : 100;

  let pontosBase = [0, 9, 14];
  let pontosExtra = [5, 13, 15, 16, 10, 6];
  let sequence = [0, 5, 9, 13, 15, 16, 14, 10, 6];
  let numVisible = floor(map(prox, 100, 500, pontosExtra.length, 0, true));
  let active = pontosBase.concat(pontosExtra.slice(0, numVisible));

  let activeIndices = [];

  for (let i = 0; i < sequence.length; i++) {
    let ponto = sequence[i];
    if (active.includes(ponto)) {
      activeIndices.push(ponto);
    }
  }

  noStroke();
  fill(cor); 
  beginShape();

  let pointsToClose = [];

  for (let i = 0; i < activeIndices.length; i++) {
    let idx = activeIndices[i];
    let kp = pose.keypoints[idx];

    if (kp && kp.confidence > 0.1) {
      let x = width - map(kp.x, 0, 640, 0, width);
      let y = map(kp.y, 0, 480, 0, height);
      
      let off = noise(i, time) * 40 - 20; 
      vertex(x + off, y + off);
      pointsToClose.push({ x: x + off, y: y + off });

      push();
      fill(0, 0, 100, 0.8); 
      ellipse(x + off, y + off, 6, 6);
      pop();
    }
  }

  if (pointsToClose.length > 2) {
    for (let i = 0; i < 3; i++) {
      vertex(pointsToClose[i].x, pointsToClose[i].y);
    }
  }
  endShape(CLOSE);

}